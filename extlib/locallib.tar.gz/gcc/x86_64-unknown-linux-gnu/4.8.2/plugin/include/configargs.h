/* Generated automatically. */
static const char configuration_arguments[] = "../configure -enable-checking=release -enable-languages=c,c++ -disable-multilib";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
